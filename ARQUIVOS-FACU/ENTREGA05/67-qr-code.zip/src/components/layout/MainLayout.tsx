import React from 'react';
import { motion } from 'motion/react';
import { LucideQrCode, Sun, Moon, Sparkles } from 'lucide-react';

interface MainLayoutProps {
  children: React.ReactNode;
  fgColor: string;
  bgColor: string;
  theme: 'light' | 'dark' | 'classic';
  onToggleTheme: () => void;
}

export const MainLayout: React.FC<MainLayoutProps> = ({ children, fgColor, bgColor, theme, onToggleTheme }) => {
  React.useEffect(() => {
    document.documentElement.style.setProperty('--primary', fgColor);
    document.documentElement.style.setProperty('--background', bgColor);
  }, [fgColor, bgColor]);

  const isDark = theme === 'dark';
  const isClassic = theme === 'classic';
  const isLight = theme === 'light';

  return (
    <div 
      className={`min-h-screen flex flex-col font-sans transition-all duration-700 ease-in-out ${isDark ? 'dark bg-black text-white' : 'bg-white text-zinc-900'}`}
      style={{ 
        background: isClassic 
          ? `radial-gradient(circle at 50% 0%, ${fgColor}15 0%, #fff 70%)` 
          : isDark ? '#000' : '#fff'
      }}
    >
      {/* Top Bar */}
      <motion.header 
        className={`w-full py-16 px-6 flex flex-col items-center justify-center transition-all duration-700 ease-in-out relative overflow-hidden ${
          isClassic ? 'text-white' : isDark ? 'text-white border-b border-zinc-900' : 'text-zinc-900 border-b border-zinc-100'
        }`}
        style={{ 
          background: isClassic 
            ? `linear-gradient(135deg, ${fgColor} 0%, ${bgColor} 100%)` 
            : isDark ? '#000' : '#fff',
          boxShadow: isClassic ? `0 10px 40px -10px ${fgColor}40` : 'none'
        }}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className={`absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] pointer-events-none ${!isClassic && 'hidden'}`} />
        
        <div className="max-w-7xl w-full flex flex-col items-center text-center gap-6 relative z-10">
          <div className="flex flex-col items-center gap-4">
            <div className={`p-5 backdrop-blur-md rounded-[2rem] border transition-all duration-500 shadow-2xl ${
              isClassic 
                ? 'bg-white/20 border-white/30' 
                : isDark ? 'bg-zinc-900/50 border-zinc-800' : 'bg-zinc-50 border-zinc-200'
            }`}>
              <LucideQrCode 
                size={64} 
                strokeWidth={2.5} 
                className={!isClassic ? 'transition-colors' : ''}
                style={!isClassic ? { color: fgColor } : {}}
              />
            </div>
            
            <div className="flex flex-col items-center gap-2">
              <h1 className="text-6xl md:text-8xl font-black tracking-tighter uppercase leading-none drop-shadow-2xl">
                67 QR CODE
              </h1>
              
              <div className="flex flex-col items-center gap-3 mt-4">
                <div className={`flex items-center gap-2 text-xs font-black uppercase tracking-[0.4em] opacity-90 ${!isClassic && (isDark ? 'text-zinc-500' : 'text-zinc-400')}`}>
                  <span>Personalização • Estilo • Profissional</span>
                </div>
                <div className={`h-px w-12 ${isClassic ? 'bg-white/30' : 'bg-zinc-200'} rounded-full`} />
                <p className={`text-[10px] uppercase tracking-[0.5em] font-black ${isClassic ? 'opacity-100' : 'text-zinc-500'}`}>
                  A tecnologia que reflete sua identidade
                </p>
              </div>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-7xl mx-auto p-6 md:p-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {children}
        </div>
      </main>

      {/* Footer & Theme Toggle */}
      <footer className="py-12 px-6 flex flex-col items-center gap-8 border-t border-zinc-200/10 transition-colors">
        <button 
          onClick={onToggleTheme}
          className={`flex items-center gap-3 px-10 py-5 rounded-[2rem] font-black uppercase tracking-widest text-[10px] transition-all shadow-xl hover:scale-105 active:scale-95 ${
            isDark 
              ? 'bg-white text-black hover:bg-zinc-100' 
              : 'bg-zinc-900 text-white hover:bg-zinc-800'
          }`}
        >
          {theme === 'light' ? (
            <>
              <Moon size={16} />
              Ativar Modo Escuro
            </>
          ) : theme === 'dark' ? (
            <>
              <Sparkles size={16} />
              Ativar Modo Clássico
            </>
          ) : (
            <>
              <Sun size={16} />
              Ativar Modo Claro
            </>
          )}
        </button>

        <div className="flex flex-col items-center gap-2">
          <p className="text-zinc-400 text-[10px] uppercase tracking-[0.3em] font-black">
            &copy; {new Date().getFullYear()} 67 QR CODE • DNA DIGITAL
          </p>
        </div>
      </footer>
    </div>
  );
};

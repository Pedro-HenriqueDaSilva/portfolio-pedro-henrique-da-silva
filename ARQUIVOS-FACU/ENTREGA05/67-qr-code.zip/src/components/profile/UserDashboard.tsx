import React, { useEffect, useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { getSavedConfigs, getAssets, saveAsset } from '../../lib/firebase';
import { X, Folder, Image as ImageIcon, Plus, Trash2, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { QRConfig } from '../../types/qr';

interface UserDashboardProps {
  onClose: () => void;
  onUpdateConfig: (updates: Partial<QRConfig>) => void;
  onProjectNameChange: (name: string) => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({ onClose, onUpdateConfig, onProjectNameChange }) => {
  const { user } = useAuth();
  const [configs, setConfigs] = useState<any[]>([]);
  const [assets, setAssets] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'projects' | 'gallery'>('projects');
  const [loading, setLoading] = useState(true);

  // Detect theme from document class
  const isDark = document.documentElement.classList.contains('dark');

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const savedConfigs = await getSavedConfigs(user.uid);
      const savedAssets = await getAssets(user.uid);
      setConfigs(savedConfigs);
      setAssets(savedAssets);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApplyConfig = (configData: any) => {
    onUpdateConfig(configData.config);
    onProjectNameChange(configData.name);
    onClose();
  };

  const handleUseAsset = (url: string) => {
    onUpdateConfig({ 
      imageSrc: url, 
      includeImage: true
    });
    onClose();
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className={`w-full max-w-4xl h-[80vh] rounded-[3rem] shadow-2xl overflow-hidden flex flex-col border transition-colors ${
          isDark ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-white border-zinc-100 text-zinc-900'
        }`}
      >
        {/* Header */}
        <div className={`p-8 border-b flex items-center justify-between ${
          isDark ? 'bg-zinc-900/50 border-zinc-800' : 'bg-zinc-50/50 border-zinc-100'
        }`}>
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg ${
              isDark ? 'bg-white text-zinc-900' : 'bg-zinc-900 text-white'
            }`}>
              <Folder size={24} />
            </div>
            <div>
              <h2 className="text-2xl font-black tracking-tight uppercase leading-none">Meus Projetos</h2>
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mt-1">Gerencie suas criações e arquivos</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className={`p-3 rounded-2xl transition-colors ${
              isDark ? 'hover:bg-zinc-800 text-zinc-500 hover:text-white' : 'hover:bg-zinc-200 text-zinc-400 hover:text-zinc-900'
            }`}
          >
            <X size={24} />
          </button>
        </div>

        {/* Tabs */}
        <div className={`flex px-8 pt-6 gap-8 border-b ${
          isDark ? 'border-zinc-800' : 'border-zinc-100'
        }`}>
          <button 
            onClick={() => setActiveTab('projects')}
            className={`pb-4 text-xs font-black uppercase tracking-[0.2em] transition-all relative ${
              activeTab === 'projects' 
                ? (isDark ? 'text-white' : 'text-zinc-900') 
                : 'text-zinc-300 hover:text-zinc-500'
            }`}
          >
            Projetos Salvos
            {activeTab === 'projects' && (
              <motion.div layoutId="tab" className={`absolute bottom-0 left-0 right-0 h-1 rounded-full ${isDark ? 'bg-white' : 'bg-zinc-900'}`} />
            )}
          </button>
          <button 
            onClick={() => setActiveTab('gallery')}
            className={`pb-4 text-xs font-black uppercase tracking-[0.2em] transition-all relative ${
              activeTab === 'gallery' 
                ? (isDark ? 'text-white' : 'text-zinc-900') 
                : 'text-zinc-300 hover:text-zinc-500'
            }`}
          >
            Galeria de Fotos
            {activeTab === 'gallery' && (
              <motion.div layoutId="tab" className={`absolute bottom-0 left-0 right-0 h-1 rounded-full ${isDark ? 'bg-white' : 'bg-zinc-900'}`} />
            )}
          </button>
        </div>

        {/* Content */}
        <div className={`flex-1 overflow-y-auto p-8 custom-scrollbar ${isDark ? 'bg-zinc-900' : 'bg-white'}`}>
          {loading ? (
            <div className="h-full flex flex-col items-center justify-center gap-4 text-zinc-300">
              <div className={`w-12 h-12 border-4 rounded-full animate-spin ${
                isDark ? 'border-zinc-800 border-t-white' : 'border-zinc-100 border-t-zinc-900'
              }`} />
              <span className="text-[10px] font-black uppercase tracking-widest">Carregando seus dados...</span>
            </div>
          ) : (
            <>
              {activeTab === 'projects' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {configs.length > 0 ? configs.map((item) => (
                    <div 
                      key={item.id}
                      className={`group rounded-[2rem] p-6 border transition-all hover:shadow-xl ${
                        isDark 
                          ? 'bg-zinc-800 border-zinc-700 hover:border-zinc-500 hover:shadow-black/50' 
                          : 'bg-zinc-50 border-zinc-100 hover:border-zinc-300 hover:shadow-zinc-200/50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center border shadow-sm ${
                          isDark ? 'bg-zinc-900 border-zinc-700 text-white' : 'bg-white border-zinc-100 text-zinc-900'
                        }`}>
                          <Folder size={20} />
                        </div>
                        <span className="text-[8px] font-black text-zinc-300 uppercase tracking-widest">
                          {new Date(item.createdAt?.toDate?.() || Date.now()).toLocaleDateString()}
                        </span>
                      </div>
                      <h3 className="text-sm font-black uppercase tracking-tight truncate mb-1">
                        {item.name || 'Projeto sem nome'}
                      </h3>
                      <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-tighter mb-4">
                        {item.config.value}
                      </p>
                      <button 
                        onClick={() => handleApplyConfig(item)}
                        className={`w-full py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${
                          isDark 
                            ? 'bg-white text-black hover:bg-zinc-100' 
                            : 'bg-zinc-900 text-white hover:bg-zinc-800'
                        }`}
                      >
                        Carregar Projeto
                      </button>
                    </div>
                  )) : (
                    <div className="col-span-full py-20 flex flex-col items-center justify-center gap-4 text-zinc-300">
                      <Folder size={48} strokeWidth={1} />
                      <p className="text-xs font-black uppercase tracking-widest">Nenhum projeto salvo ainda</p>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'gallery' && (
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                  {assets.length > 0 ? assets.map((asset) => (
                    <div 
                      key={asset.id}
                      className={`group relative aspect-square rounded-2xl overflow-hidden border transition-all ${
                        isDark ? 'border-zinc-700 bg-zinc-800' : 'border-zinc-100 bg-zinc-50'
                      }`}
                    >
                      <img 
                        src={asset.url} 
                        alt={asset.name} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                         <button 
                          className="p-2 bg-white rounded-lg text-zinc-900 hover:bg-zinc-100 transition-transform active:scale-90"
                          title="Usar esta foto"
                          onClick={() => handleUseAsset(asset.url)}
                        >
                          <ExternalLink size={16} />
                        </button>
                      </div>
                    </div>
                  )) : (
                    <div className="col-span-full py-20 flex flex-col items-center justify-center gap-4 text-zinc-300">
                      <ImageIcon size={48} strokeWidth={1} />
                      <p className="text-xs font-black uppercase tracking-widest">Sua galeria está vazia</p>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
};

const configDataPlaceholder = {};

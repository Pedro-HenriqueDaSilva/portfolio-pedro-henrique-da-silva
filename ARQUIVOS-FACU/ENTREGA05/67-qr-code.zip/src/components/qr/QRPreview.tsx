import React, { useEffect, useRef } from 'react';
import QRCodeStyling, { 
  DrawType, 
  TypeNumber, 
  Mode, 
  ErrorCorrectionLevel, 
  DotType, 
  CornerSquareType, 
  CornerDotType 
} from 'qr-code-styling';
import { QRConfig } from '../../types/qr';

interface QRPreviewProps {
  config: QRConfig;
}

export const QRPreview: React.FC<QRPreviewProps> = ({ config }) => {
  const ref = useRef<HTMLDivElement>(null);
  const qrCode = useRef<QRCodeStyling>(new QRCodeStyling({
    width: config.width,
    height: config.height,
    data: config.value,
    margin: config.margin,
    qrOptions: {
      typeNumber: 0 as TypeNumber,
      mode: 'Byte' as Mode,
      errorCorrectionLevel: config.level as ErrorCorrectionLevel
    },
    imageOptions: {
      hideBackgroundDots: true,
      imageSize: 0.4,
      margin: 0
    },
    dotsOptions: {
      type: (config.style === 'squares' ? 'square' : config.style === 'dots' ? 'dots' : 'rounded') as DotType,
      color: config.fgColor
    },
    backgroundOptions: {
      color: config.bgColor
    },
    cornersSquareOptions: {
      type: (config.eyeStyle === 'circle' ? 'dot' : config.eyeStyle === 'rounded' ? 'extra-rounded' : 'square') as CornerSquareType,
      color: config.fgColor
    },
    cornersDotOptions: {
      type: (config.eyeStyle === 'circle' ? 'dot' : 'square') as CornerDotType,
      color: config.fgColor
    }
  }));

  useEffect(() => {
    if (ref.current) {
      qrCode.current.append(ref.current);
    }
  }, []);

  useEffect(() => {
    qrCode.current.update({
      width: config.width,
      height: config.height,
      data: config.value,
      margin: config.margin,
      qrOptions: {
        errorCorrectionLevel: config.level as ErrorCorrectionLevel
      },
      dotsOptions: {
        type: (config.style === 'squares' ? 'square' : 
               config.style === 'dots' ? 'dots' : 
               config.style === 'rounded' ? 'rounded' : 
               config.style === 'extra-rounded' ? 'extra-rounded' :
               config.style === 'classy' ? 'classy' :
               config.style === 'classy-rounded' ? 'classy-rounded' :
               'rounded') as DotType,
        color: config.fgColor
      },
      backgroundOptions: {
        color: config.bgColor
      },
      cornersSquareOptions: {
        type: (config.eyeStyle === 'circle' ? 'dot' : config.eyeStyle === 'rounded' ? 'extra-rounded' : 'square') as CornerSquareType,
        color: config.fgColor
      },
      cornersDotOptions: {
        type: (config.eyeStyle === 'circle' ? 'dot' : 'square') as CornerDotType,
        color: config.fgColor
      },
      image: config.includeImage ? config.imageSrc : undefined,
      imageOptions: {
        hideBackgroundDots: true,
        imageSize: (config.imageWidth || 40) / 100,
        margin: 5
      }
    });
  }, [config]);

  return (
    <div className="relative group w-full max-w-md">
      <div 
        className="bg-white/40 backdrop-blur-2xl p-6 rounded-[3rem] shadow-2xl border border-white/50 flex items-center justify-center aspect-square w-full transition-transform duration-500 hover:scale-[1.02] overflow-hidden"
        style={{ boxShadow: `0 40px 100px -20px ${config.fgColor}30` }}
      >
        <div 
          ref={ref} 
          className="qr-container"
        />
      </div>
      
      {/* Decorative elements */}
      <div className="absolute -z-10 -top-4 -right-4 w-24 h-24 bg-zinc-100 rounded-full blur-2xl opacity-50" />
      <div className="absolute -z-10 -bottom-8 -left-8 w-32 h-32 bg-zinc-200 rounded-full blur-3xl opacity-30" />
    </div>
  );
};

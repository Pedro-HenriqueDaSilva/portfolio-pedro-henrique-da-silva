import React, { useState } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { QRConfig, QRStyle } from '@/src/types/qr';
import { FileImage, Settings, Grid, Square, Circle, Image as ImageIcon, QrCode, Download, Save, Loader2, Printer } from 'lucide-react';
import { useAuth } from '@/src/hooks/useAuth';
import { saveQRConfig, saveAsset, uploadToStorage } from '@/src/lib/firebase';

interface QRControlsProps {
  config: QRConfig;
  onUpdate: (updates: Partial<QRConfig>) => void;
  projectName: string;
  onProjectNameChange: (name: string) => void;
}

export const QRControls: React.FC<QRControlsProps> = ({ 
  config, 
  onUpdate, 
  projectName, 
  onProjectNameChange 
}) => {
  const { user } = useAuth();
  const [saving, setSaving] = useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const result = event.target?.result as string;
        onUpdate({ 
          imageSrc: result,
          includeImage: true
        });

        // Save to storage and gallery if logged in
        if (user) {
          try {
            const fileName = `${Date.now()}-${file.name}`;
            const storagePath = `gallery/${fileName}`;
            const downloadUrl = await uploadToStorage(user.uid, storagePath, result);
            await saveAsset(user.uid, file.name, downloadUrl);
          } catch (err) {
            console.error('Error saving asset to Storage:', err);
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDownload = () => {
    const canvas = document.querySelector('canvas');
    if (canvas) {
      const url = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      const fileName = projectName.toLowerCase().replace(/[^a-z0-9]/g, '-') || 'qrcode';
      link.download = `${fileName}.png`;
      link.href = url;
      link.click();
    }
  };

  const handleSaveProject = async () => {
    if (!user) {
      alert('Faça login para salvar seus projetos!');
      return;
    }
    if (!projectName) {
      alert('Dê um nome ao seu projeto para salvar!');
      return;
    }

    setSaving(true);
    try {
      // Create a snapshot of the QR code to save in Storage
      const canvas = document.querySelector('canvas');
      let qrImageUrl = '';
      if (canvas) {
        const dataUrl = canvas.toDataURL('image/png');
        const fileName = `${Date.now()}-${projectName.replace(/[^a-z0-9]/gi, '_')}.png`;
        const storagePath = `projects/${fileName}`;
        qrImageUrl = await uploadToStorage(user.uid, storagePath, dataUrl);
      }

      await saveQRConfig(user.uid, projectName, {
        ...config,
        previewUrl: qrImageUrl
      });
      
      alert('Sincronizado com Sucesso! Seu QR Code e imagem estão salvos na nuvem.');
    } catch (err) {
      console.error('Error saving project:', err);
      alert('Atenção: Não foi possível salvar na nuvem. Verifique sua conexão ou tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  const handlePrint = () => {
    const canvas = document.querySelector('canvas');
    if (!canvas) {
      alert('QR Code não disponível para impressão.');
      return;
    }
    const dataUrl = canvas.toDataURL();
    const windowPrint = window.open('', '_blank');
    if (windowPrint) {
      windowPrint.document.write(`
        <html>
          <head>
            <title>Imprimir QR Code</title>
            <style>
              body { display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
              img { max-width: 100%; height: auto; }
            </style>
          </head>
          <body>
            <img src="${dataUrl}" onload="window.print();window.close();" />
          </body>
        </html>
      `);
      windowPrint.document.close();
    }
  };

  const exportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(config, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "qr-config.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  return (
    <div className="space-y-10">
      {/* Dados Principais */}
      <section className="space-y-6">
        <div className="flex items-center gap-2 mb-4">
          <Settings className="text-zinc-400" size={18} />
          <h3 className="text-sm font-black uppercase tracking-widest text-zinc-500">Dados Principais</h3>
        </div>

          <div className="space-y-4">
            <div className="flex flex-col gap-4">
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 text-left block">Nome do Arquivo / Projeto</Label>
                <div className="flex gap-2">
                  <Input 
                    value={projectName}
                    onChange={(e) => onProjectNameChange(e.target.value)}
                    placeholder="Ex: Identidade 2024"
                    className="h-12 flex-1 rounded-xl border-zinc-200"
                  />
                  <button 
                    onClick={handleSaveProject}
                    disabled={saving || !user}
                    className="h-12 px-6 bg-zinc-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-zinc-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 whitespace-nowrap shadow-lg active:scale-95"
                    title="Sincronizar com Nuvem"
                  >
                    {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                    {saving ? 'Sincronizando...' : 'Salvar'}
                  </button>
                </div>
                <p className="text-[9px] text-zinc-400 font-bold uppercase tracking-widest leading-relaxed">Clique em Salvar para enviar o QR Code e as configurações para o seu banco de dados na nuvem.</p>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-400">DADOS</Label>
              <Input 
                value={config.value}
                onChange={(e) => onUpdate({ value: e.target.value })}
                placeholder="URL ou Texto"
                className="h-12 rounded-xl border-zinc-200"
              />
            </div>

          <div className="space-y-4">
            <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Logotipo no Centro</Label>
            <div className="flex flex-col gap-3">
              <div className="relative group">
                <input 
                  type="file"
                  id="qr-image-upload"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <label 
                  htmlFor="qr-image-upload"
                  className="flex items-center justify-center gap-3 w-full h-16 rounded-2xl border-2 border-dashed border-zinc-200 dark:border-zinc-700 cursor-pointer hover:border-zinc-900 dark:hover:border-zinc-500 hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-all group-active:scale-[0.98]"
                >
                  <div className="p-2 bg-zinc-900 dark:bg-zinc-100 dark:text-zinc-900 text-white rounded-lg group-hover:scale-110 transition-transform">
                    <ImageIcon size={20} />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black uppercase tracking-widest text-zinc-900 dark:text-white">Importar Imagem</span>
                    <span className="text-[8px] font-bold text-zinc-400 uppercase tracking-tighter">SVG, PNG ou JPG</span>
                  </div>
                </label>
              </div>

              {(config.imageSrc) && (
                <button 
                  onClick={() => onUpdate({ includeImage: false, imageSrc: undefined })}
                  className="w-full py-3 bg-red-50 dark:bg-red-900/20 text-red-500 dark:text-red-400 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-100 dark:hover:bg-red-900/40 transition-colors flex items-center justify-center gap-2"
                >
                  Remover Logotipo Atual
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 pt-2">
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Largura</Label>
              <Input 
                type="number"
                value={config.width}
                onChange={(e) => onUpdate({ width: Number(e.target.value) })}
                className="h-10 rounded-lg border-zinc-200"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Altura</Label>
              <Input 
                type="number"
                value={config.height}
                onChange={(e) => onUpdate({ height: Number(e.target.value) })}
                className="h-10 rounded-lg border-zinc-200"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Margem</Label>
              <Input 
                type="number"
                value={config.margin}
                onChange={(e) => onUpdate({ margin: Number(e.target.value) })}
                className="h-10 rounded-lg border-zinc-200"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Expandable Options */}
      <Accordion type="single" collapsible className="w-full">
        {/* Opções de Cores */}
        <AccordionItem value="dots" className="border-zinc-100">
          <AccordionTrigger className="hover:no-underline py-4">
            <div className="flex items-center gap-3">
              <Grid size={18} className="text-zinc-400" />
              <span className="text-xs font-black uppercase tracking-widest text-zinc-600">Opções de Cores</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Cor das Linhas</Label>
                <div className="flex gap-2 items-center">
                  <Input 
                    type="color"
                    value={config.fgColor}
                    onChange={(e) => onUpdate({ fgColor: e.target.value })}
                    className="h-12 w-20 rounded-xl border-zinc-200 cursor-pointer p-1"
                  />
                  <Input 
                    value={config.fgColor}
                    onChange={(e) => onUpdate({ fgColor: e.target.value })}
                    className="h-12 flex-1 rounded-xl border-zinc-200 font-mono text-xs uppercase"
                  />
                </div>
              </div>
              <div className="space-y-3">
                <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Cor de Fundo</Label>
                <div className="flex gap-2 items-center">
                  <Input 
                    type="color"
                    value={config.bgColor}
                    onChange={(e) => onUpdate({ bgColor: e.target.value })}
                    className="h-12 w-20 rounded-xl border-zinc-200 cursor-pointer p-1"
                  />
                  <Input 
                    value={config.bgColor}
                    onChange={(e) => onUpdate({ bgColor: e.target.value })}
                    className="h-12 flex-1 rounded-xl border-zinc-200 font-mono text-xs uppercase"
                  />
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Opções de Estilo */}
        <AccordionItem value="squares" className="border-zinc-100">
          <AccordionTrigger className="hover:no-underline py-4">
            <div className="flex items-center gap-3">
              <Square size={18} className="text-zinc-400" />
              <span className="text-xs font-black uppercase tracking-widest text-zinc-600">Opções de Estilo</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-6">
            <Select 
              value={config.style} 
              onValueChange={(val: QRStyle) => onUpdate({ style: val })}
            >
              <SelectTrigger className="h-12 rounded-xl border-zinc-200 font-bold">
                <SelectValue placeholder="Selecione o estilo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="squares">Quadrados</SelectItem>
                <SelectItem value="dots">Pontos</SelectItem>
                <SelectItem value="rounded">Arredondado</SelectItem>
                <SelectItem value="extra-rounded">Extra Arredondado</SelectItem>
                <SelectItem value="classy">Classy</SelectItem>
                <SelectItem value="classy-rounded">Classy Arredondado</SelectItem>
              </SelectContent>
            </Select>
          </AccordionContent>
        </AccordionItem>

        {/* Opções de Cantos */}
        <AccordionItem value="corners" className="border-zinc-100">
          <AccordionTrigger className="hover:no-underline py-4">
            <div className="flex items-center gap-3">
              <Circle size={18} className="text-zinc-400" />
              <span className="text-xs font-black uppercase tracking-widest text-zinc-600">Opções de Cantos</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-6">
            <div className="grid grid-cols-3 gap-2">
              {['square', 'circle', 'rounded'].map((style) => (
                <button
                  key={style}
                  onClick={() => onUpdate({ eyeStyle: style as any })}
                  className={`py-3 rounded-xl border text-[10px] font-black uppercase tracking-widest transition-all ${
                    config.eyeStyle === style 
                      ? 'bg-zinc-900 text-white border-zinc-900 shadow-lg' 
                      : 'bg-white text-zinc-400 border-zinc-100 hover:border-zinc-200'
                  }`}
                >
                  {style}
                </button>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Opções de Imagem */}
        <AccordionItem value="image" className="border-zinc-100">
          <AccordionTrigger className="hover:no-underline py-4">
            <div className="flex items-center gap-3">
              <ImageIcon size={18} className="text-zinc-400" />
              <span className="text-xs font-black uppercase tracking-widest text-zinc-600">Opções de Imagem</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-6 space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Largura Logo</Label>
                <Slider 
                  value={[config.imageWidth || 40]}
                  min={20}
                  max={100}
                  onValueChange={(vals) => {
                    const val = Array.isArray(vals) ? vals[0] : vals;
                    onUpdate({ imageWidth: val });
                  }}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Opacidade</Label>
                <Slider 
                  value={[(config.imageOpacity || 1) * 100]}
                  min={0}
                  max={100}
                  onValueChange={(vals) => {
                    const val = Array.isArray(vals) ? vals[0] : vals;
                    onUpdate({ imageOpacity: val / 100 });
                  }}
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Opções de QRcode */}
        <AccordionItem value="qrcode" className="border-zinc-100">
          <AccordionTrigger className="hover:no-underline py-4">
            <div className="flex items-center gap-3">
              <QrCode size={18} className="text-zinc-400" />
              <span className="text-xs font-black uppercase tracking-widest text-zinc-600">Opções de QRcode</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-6">
            <div className="space-y-3">
              <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Correção de Erro</Label>
              <Select 
                value={config.level} 
                onValueChange={(val: any) => onUpdate({ level: val })}
              >
                <SelectTrigger className="h-12 rounded-xl border-zinc-200 font-bold">
                  <SelectValue placeholder="Nível de Erro" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="L">Baixo (7%)</SelectItem>
                  <SelectItem value="M">Médio (15%)</SelectItem>
                  <SelectItem value="Q">Quartil (25%)</SelectItem>
                  <SelectItem value="H">Alto (30%)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Opção de Exportar */}
        <AccordionItem value="export" className="border-none">
          <AccordionTrigger className="hover:no-underline py-4">
            <div className="flex items-center gap-3">
              <Download size={18} className="text-zinc-400" />
              <span className="text-xs font-black uppercase tracking-widest text-zinc-600">Opções de Exportação</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-6 space-y-2">
            <button 
              onClick={handleDownload}
              className="w-full py-4 bg-zinc-900 text-white rounded-xl font-black uppercase tracking-widest text-xs hover:bg-zinc-800 transition-all flex items-center justify-center gap-2"
            >
              <Download size={14} />
              Baixar PNG ({projectName})
            </button>
            <div className="grid grid-cols-2 gap-2">
              <button 
                onClick={exportJSON}
                className="py-4 bg-zinc-100 text-zinc-900 rounded-xl font-black uppercase tracking-widest text-[10px] hover:bg-zinc-200 transition-all flex items-center justify-center gap-2"
              >
                <Download size={14} />
                JSON
              </button>
              <button 
                onClick={handlePrint}
                className="py-4 bg-zinc-100 text-zinc-900 rounded-xl font-black uppercase tracking-widest text-[10px] hover:bg-zinc-200 transition-all flex items-center justify-center gap-2"
              >
                <Printer size={14} />
                Imprimir
              </button>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
};

import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';
import { getFirestore, doc, setDoc, getDoc, collection, query, where, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
import { getStorage, ref as storageRef, uploadString, getDownloadURL, uploadBytes } from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();

export const loginWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    
    // Save or update user profile
    await setDoc(doc(db, 'users', user.uid), {
      uid: user.uid,
      email: user.email,
      displayName: user.displayName,
      photoURL: user.photoURL,
      lastLogin: serverTimestamp(),
      isAdmin: true // All users are admins in this context
    }, { merge: true });
    
    return user;
  } catch (error) {
    console.error('Login error:', error);
    throw error;
  }
};

export const logout = () => signOut(auth);

// Save QR Config
export const saveQRConfig = async (userId: string, name: string, config: any) => {
  const collRef = collection(db, 'users', userId, 'savedConfigs');
  await addDoc(collRef, {
    userId,
    name,
    config,
    createdAt: serverTimestamp()
  });
};

// Upload to Storage
export const uploadToStorage = async (userId: string, path: string, dataUrl: string) => {
  const storagePath = `users/${userId}/${path}`;
  const fileRef = storageRef(storage, storagePath);
  await uploadString(fileRef, dataUrl, 'data_url');
  return await getDownloadURL(fileRef);
};

// Get Saved QR Configs
export const getSavedConfigs = async (userId: string) => {
  const collRef = collection(db, 'users', userId, 'savedConfigs');
  const q = query(collRef, where('userId', '==', userId));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

// Save Asset
export const saveAsset = async (userId: string, name: string, url: string) => {
  const collRef = collection(db, 'users', userId, 'assets');
  await addDoc(collRef, {
    userId,
    name,
    url,
    createdAt: serverTimestamp()
  });
};

// Get Assets
export const getAssets = async (userId: string) => {
  const collRef = collection(db, 'users', userId, 'assets');
  const snapshot = await getDocs(collRef);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

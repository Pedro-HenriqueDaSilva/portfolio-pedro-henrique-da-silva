/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MainLayout } from './components/layout/MainLayout';
import { useQRCode } from './hooks/useQRCode';
import { QRControls } from './components/qr/QRControls';
import { QRPreview } from './components/qr/QRPreview';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { LogOut, User as UserIcon, LogIn, LayoutDashboard, Image as ImageIcon } from 'lucide-react';
import { UserDashboard } from './components/profile/UserDashboard';
import { useState } from 'react';
import { AnimatePresence } from 'motion/react';

function AppContent() {
  const { config, updateConfig } = useQRCode();
  const { user, login, logout, loading } = useAuth();
  const [showDashboard, setShowDashboard] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark' | 'classic'>('light');
  const [projectName, setProjectName] = useState('Meu QR Code');

  const handleDownload = () => {
    const canvas = document.querySelector('canvas');
    if (canvas) {
      const url = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      const fileName = projectName.toLowerCase().replace(/[^a-z0-9]/g, '-') || 'qrcode';
      link.download = `${fileName}.png`;
      link.href = url;
      link.click();
    }
  };

  const toggleTheme = () => {
    let nextTheme: 'light' | 'dark' | 'classic' = 'light';
    if (theme === 'light') nextTheme = 'dark';
    else if (theme === 'dark') nextTheme = 'classic';
    else nextTheme = 'light';

    setTheme(nextTheme);
    if (nextTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  return (
    <MainLayout 
      fgColor={config.fgColor} 
      bgColor={config.bgColor} 
      theme={theme} 
      onToggleTheme={toggleTheme}
    >
      <AnimatePresence>
        {showDashboard && (
          <UserDashboard 
            onClose={() => setShowDashboard(false)} 
            onUpdateConfig={(updates) => updateConfig(updates)}
            onProjectNameChange={setProjectName}
          />
        )}
      </AnimatePresence>

      {/* Auth / Admin Bar */}
      <div className="col-span-1 lg:col-span-2 flex justify-end items-center gap-4 mb-2">
        {loading ? (
          <div className="w-8 h-8 rounded-full bg-zinc-200 animate-pulse" />
        ) : user ? (
          <div className={`flex items-center gap-4 backdrop-blur-sm p-2 pr-4 rounded-full border shadow-sm transition-all ${
            theme === 'dark' ? 'bg-zinc-900/50 border-zinc-700 hover:bg-zinc-900/80' : 'bg-white/50 border-zinc-200 hover:bg-white/80'
          }`}>
            <button 
              onClick={() => setShowDashboard(true)}
              className="group relative flex items-center gap-4"
            >
              {user.photoURL ? (
                <img src={user.photoURL} alt={user.displayName || ''} className="w-8 h-8 rounded-full border border-zinc-300 transition-transform group-hover:scale-110" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-zinc-900 flex items-center justify-center text-white">
                  <UserIcon size={16} />
                </div>
              )}
              <div className="flex flex-col text-left">
                <span className={`text-[10px] font-black uppercase tracking-widest ${theme === 'dark' ? 'text-white' : 'text-zinc-900'}`}>{user.displayName || user.email}</span>
                <span className={`text-[8px] font-bold uppercase tracking-tighter flex items-center gap-1 transition-colors ${theme === 'dark' ? 'text-zinc-500 group-hover:text-zinc-300' : 'text-zinc-400 group-hover:text-zinc-600'}`}>
                  <LayoutDashboard size={8} />
                  Ver Dashboard
                </span>
              </div>
            </button>
            <div className={`w-px h-6 mx-1 ${theme === 'dark' ? 'bg-zinc-700' : 'bg-zinc-200'}`} />
            <button 
              onClick={() => logout()}
              className="p-1.5 hover:bg-zinc-100 rounded-lg text-zinc-400 hover:text-red-500 transition-colors"
              title="Sair"
            >
              <LogOut size={16} />
            </button>
          </div>
        ) : (
          <button 
            onClick={() => login()}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all shadow-lg ${
              theme === 'dark' ? 'bg-white text-black hover:bg-zinc-100 hover:shadow-white/10' : 'bg-zinc-900 text-white hover:bg-zinc-800 shadow-zinc-900/20'
            }`}
          >
            <LogIn size={14} />
            Entrar com Google
          </button>
        )}
      </div>

      {/* Left Column: Controls */}
      <div className="space-y-8">
        <div className={`backdrop-blur-xl p-8 md:p-10 rounded-[2.5rem] shadow-xl border ${
          theme === 'dark' ? 'bg-zinc-900/80 border-zinc-800' : 'bg-white/80 border-white/40'
        }`}>
          <div className="flex items-center justify-between mb-8 gap-4">
            <h2 className={`text-3xl font-black tracking-tight uppercase grow ${theme === 'dark' ? 'text-white' : 'text-zinc-900'}`}>Customização</h2>
            <div className="flex items-center gap-2">
              <label 
                htmlFor="qr-image-upload" 
                className={`cursor-pointer flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  theme === 'dark' ? 'bg-white text-black hover:bg-zinc-200' : 'bg-zinc-900 text-white hover:bg-zinc-800'
                }`}
              >
                <ImageIcon size={14} />
                Importar
              </label>
              <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest hidden sm:block ${
                theme === 'dark' ? 'bg-white/10 text-white' : 'bg-zinc-900/10 text-zinc-900'
              }`}>
                Personalize seu 67
              </div>
            </div>
          </div>
          
          <QRControls 
            config={config} 
            onUpdate={updateConfig} 
            projectName={projectName}
            onProjectNameChange={setProjectName}
          />
        </div>
      </div>

      {/* Right Column: Preview */}
      <div className="flex flex-col items-center justify-start">
        <div className="sticky top-10 w-full flex flex-col items-center">
          <QRPreview config={config} />
          
          <div className="mt-10 w-full max-w-md space-y-4">
             <button 
              className="w-full py-5 text-white rounded-[1.5rem] font-black uppercase tracking-[0.2em] transition-all active:scale-[0.98] shadow-xl flex items-center justify-center gap-3"
              style={{ backgroundColor: config.fgColor, boxShadow: `0 20px 40px -10px ${config.fgColor}40` }}
              onClick={handleDownload}
            >
              Exportar QR Code
            </button>
            <p className="text-center text-zinc-400 text-[10px] uppercase font-bold tracking-widest">
              Formato PNG • Alta Resolução • Profissional
            </p>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}



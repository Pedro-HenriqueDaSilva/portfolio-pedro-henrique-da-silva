import { useState } from 'react';
import { QRConfig, DEFAULT_QR_CONFIG } from '../types/qr';

export function useQRCode() {
  const [config, setConfig] = useState<QRConfig>(DEFAULT_QR_CONFIG);

  const updateConfig = (updates: Partial<QRConfig>) => {
    setConfig((prev) => ({ ...prev, ...updates }));
  };

  return {
    config,
    updateConfig,
  };
}

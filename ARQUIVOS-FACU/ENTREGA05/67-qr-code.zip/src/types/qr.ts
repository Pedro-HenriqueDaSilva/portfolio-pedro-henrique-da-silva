export type QRStyle = 'squares' | 'dots' | 'rounded' | 'extra-rounded' | 'classy' | 'classy-rounded' | 'fluid' | 'organic' | 'starry';
export type QRErrorCorrection = 'L' | 'M' | 'Q' | 'H';

export interface QRConfig {
  value: string;
  width: number;
  height: number;
  margin: number;
  fgColor: string;
  bgColor: string;
  level: QRErrorCorrection;
  style: QRStyle;
  includeImage: boolean;
  imageSrc?: string;
  imageWidth?: number;
  imageHeight?: number;
  imageOpacity?: number;
  eyeStyle?: 'square' | 'circle' | 'rounded';
}

export const DEFAULT_QR_CONFIG: QRConfig = {
  value: 'https://google.com',
  width: 300,
  height: 300,
  margin: 10,
  fgColor: '#000000',
  bgColor: '#ffffff',
  level: 'M',
  style: 'squares',
  includeImage: false,
  imageWidth: 60,
  imageHeight: 60,
  imageOpacity: 1,
  eyeStyle: 'square',
};
